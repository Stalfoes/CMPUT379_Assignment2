#ifndef __TANDS_H__
#define __TANDS_H__
extern "C" {
	void Trans(int n);
	void Sleep(int n);
};
#endif
